﻿namespace WindowsFormsApp1
{
    partial class Principal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Principal));
            panelLado = new Panel();
            panelCerrar = new Panel();
            buttonCerrar = new Button();
            picLogo = new PictureBox();
            panelTitulo = new Panel();
            labSubTituto = new Label();
            labTituto = new Label();
            panelVisualCitas = new Panel();
            paDiasBloq = new Panel();
            labelNumBloqueados = new Label();
            labelBloqueados = new Label();
            pictureBloqueados = new PictureBox();
            paCitasCan = new Panel();
            labelNumCanceladas = new Label();
            labelCanceladas = new Label();
            pictureCanceladas = new PictureBox();
            PCitasProx = new Panel();
            labelNumProx = new Label();
            labelProx = new Label();
            pictureProx = new PictureBox();
            pCitasHoy = new Panel();
            labelNumCitas = new Label();
            labelHoy = new Label();
            pictureCitas = new PictureBox();
            comboBoxFiltrar1 = new ComboBox();
            BusCitas = new TextBox();
            tablaCitas = new TableLayoutPanel();
            picModificar3 = new PictureBox();
            picModificar2 = new PictureBox();
            picCancelar3 = new PictureBox();
            picCancelar2 = new PictureBox();
            labEstado = new Label();
            labFecHo3 = new Label();
            labServicio3 = new Label();
            labGrupo3 = new Label();
            labCliente = new Label();
            labEstado2 = new Label();
            labFecHo2 = new Label();
            labServicio2 = new Label();
            labGrupo2 = new Label();
            labCliente2 = new Label();
            celTiCliente = new Label();
            labTiGrupo = new Label();
            labTiServicio = new Label();
            labTiFecHo = new Label();
            labTiEstado = new Label();
            labTiModificar = new Label();
            TablaUsCancelar = new Label();
            labCliente1 = new Label();
            labGrupo1 = new Label();
            labServicio1 = new Label();
            labFecHo1 = new Label();
            labEstado1 = new Label();
            picCancelar1 = new PictureBox();
            picModificar1 = new PictureBox();
            panelLado.SuspendLayout();
            panelCerrar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picLogo).BeginInit();
            panelTitulo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBloqueados).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureCanceladas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureProx).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureCitas).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picModificar3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picModificar2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picCancelar3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picCancelar2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picCancelar1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picModificar1).BeginInit();
            SuspendLayout();
            // 
            // panelLado
            // 
            panelLado.BackColor = Color.DarkOrange;
            panelLado.Controls.Add(panelCerrar);
            panelLado.Controls.Add(picLogo);
            panelLado.Dock = DockStyle.Left;
            panelLado.Location = new Point(0, 0);
            panelLado.Margin = new Padding(4, 3, 4, 3);
            panelLado.Name = "panelLado";
            panelLado.RightToLeft = RightToLeft.No;
            panelLado.Size = new Size(149, 704);
            panelLado.TabIndex = 0;
            // 
            // panelCerrar
            // 
            panelCerrar.Controls.Add(buttonCerrar);
            panelCerrar.Dock = DockStyle.Bottom;
            panelCerrar.Location = new Point(0, 634);
            panelCerrar.Name = "panelCerrar";
            panelCerrar.Padding = new Padding(10, 0, 10, 0);
            panelCerrar.Size = new Size(149, 70);
            panelCerrar.TabIndex = 7;
            // 
            // buttonCerrar
            // 
            buttonCerrar.Dock = DockStyle.Top;
            buttonCerrar.FlatStyle = FlatStyle.Popup;
            buttonCerrar.Location = new Point(10, 0);
            buttonCerrar.Name = "buttonCerrar";
            buttonCerrar.Size = new Size(129, 23);
            buttonCerrar.TabIndex = 3;
            buttonCerrar.Text = "Cerrar sesión";
            buttonCerrar.UseVisualStyleBackColor = false;
            buttonCerrar.Click += buttonCerrar_Click;
            // 
            // picLogo
            // 
            picLogo.Image = (Image)resources.GetObject("picLogo.Image");
            picLogo.Location = new Point(0, 0);
            picLogo.Name = "picLogo";
            picLogo.Size = new Size(169, 136);
            picLogo.SizeMode = PictureBoxSizeMode.Zoom;
            picLogo.TabIndex = 12;
            picLogo.TabStop = false;
            // 
            // panelTitulo
            // 
            panelTitulo.BackColor = Color.DarkOrange;
            panelTitulo.Controls.Add(labSubTituto);
            panelTitulo.Controls.Add(labTituto);
            panelTitulo.Dock = DockStyle.Top;
            panelTitulo.Location = new Point(149, 0);
            panelTitulo.Margin = new Padding(4, 3, 4, 3);
            panelTitulo.Name = "panelTitulo";
            panelTitulo.Size = new Size(1082, 136);
            panelTitulo.TabIndex = 1;
            // 
            // labSubTituto
            // 
            labSubTituto.AutoSize = true;
            labSubTituto.Font = new Font("Microsoft Sans Serif", 9.5F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labSubTituto.ForeColor = SystemColors.ControlDarkDark;
            labSubTituto.Location = new Point(15, 91);
            labSubTituto.Margin = new Padding(4, 0, 4, 0);
            labSubTituto.Name = "labSubTituto";
            labSubTituto.Size = new Size(174, 16);
            labSubTituto.TabIndex = 2;
            labSubTituto.Text = "Administra la base de datos";
            // 
            // labTituto
            // 
            labTituto.AutoSize = true;
            labTituto.Font = new Font("Microsoft Sans Serif", 25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labTituto.Location = new Point(15, 33);
            labTituto.Margin = new Padding(4, 0, 4, 0);
            labTituto.Name = "labTituto";
            labTituto.Size = new Size(272, 39);
            labTituto.TabIndex = 0;
            labTituto.Text = "Gestión general";
            // 
            // panelVisualCitas
            // 
            panelVisualCitas.Location = new Point(0, 0);
            panelVisualCitas.Name = "panelVisualCitas";
            panelVisualCitas.Size = new Size(200, 100);
            panelVisualCitas.TabIndex = 0;
            // 
            // paDiasBloq
            // 
            paDiasBloq.Location = new Point(0, 0);
            paDiasBloq.Name = "paDiasBloq";
            paDiasBloq.Size = new Size(200, 100);
            paDiasBloq.TabIndex = 0;
            // 
            // labelNumBloqueados
            // 
            labelNumBloqueados.Location = new Point(0, 0);
            labelNumBloqueados.Name = "labelNumBloqueados";
            labelNumBloqueados.Size = new Size(100, 23);
            labelNumBloqueados.TabIndex = 0;
            // 
            // labelBloqueados
            // 
            labelBloqueados.Location = new Point(0, 0);
            labelBloqueados.Name = "labelBloqueados";
            labelBloqueados.Size = new Size(100, 23);
            labelBloqueados.TabIndex = 0;
            // 
            // pictureBloqueados
            // 
            pictureBloqueados.Location = new Point(0, 0);
            pictureBloqueados.Name = "pictureBloqueados";
            pictureBloqueados.Size = new Size(100, 50);
            pictureBloqueados.TabIndex = 0;
            pictureBloqueados.TabStop = false;
            // 
            // paCitasCan
            // 
            paCitasCan.Location = new Point(0, 0);
            paCitasCan.Name = "paCitasCan";
            paCitasCan.Size = new Size(200, 100);
            paCitasCan.TabIndex = 0;
            // 
            // labelNumCanceladas
            // 
            labelNumCanceladas.Location = new Point(0, 0);
            labelNumCanceladas.Name = "labelNumCanceladas";
            labelNumCanceladas.Size = new Size(100, 23);
            labelNumCanceladas.TabIndex = 0;
            // 
            // labelCanceladas
            // 
            labelCanceladas.Location = new Point(0, 0);
            labelCanceladas.Name = "labelCanceladas";
            labelCanceladas.Size = new Size(100, 23);
            labelCanceladas.TabIndex = 0;
            // 
            // pictureCanceladas
            // 
            pictureCanceladas.Location = new Point(0, 0);
            pictureCanceladas.Name = "pictureCanceladas";
            pictureCanceladas.Size = new Size(100, 50);
            pictureCanceladas.TabIndex = 0;
            pictureCanceladas.TabStop = false;
            // 
            // PCitasProx
            // 
            PCitasProx.Location = new Point(0, 0);
            PCitasProx.Name = "PCitasProx";
            PCitasProx.Size = new Size(200, 100);
            PCitasProx.TabIndex = 0;
            // 
            // labelNumProx
            // 
            labelNumProx.Location = new Point(0, 0);
            labelNumProx.Name = "labelNumProx";
            labelNumProx.Size = new Size(100, 23);
            labelNumProx.TabIndex = 0;
            // 
            // labelProx
            // 
            labelProx.Location = new Point(0, 0);
            labelProx.Name = "labelProx";
            labelProx.Size = new Size(100, 23);
            labelProx.TabIndex = 0;
            // 
            // pictureProx
            // 
            pictureProx.Location = new Point(0, 0);
            pictureProx.Name = "pictureProx";
            pictureProx.Size = new Size(100, 50);
            pictureProx.TabIndex = 0;
            pictureProx.TabStop = false;
            // 
            // pCitasHoy
            // 
            pCitasHoy.Location = new Point(0, 0);
            pCitasHoy.Name = "pCitasHoy";
            pCitasHoy.Size = new Size(200, 100);
            pCitasHoy.TabIndex = 0;
            // 
            // labelNumCitas
            // 
            labelNumCitas.Location = new Point(0, 0);
            labelNumCitas.Name = "labelNumCitas";
            labelNumCitas.Size = new Size(100, 23);
            labelNumCitas.TabIndex = 0;
            // 
            // labelHoy
            // 
            labelHoy.Location = new Point(0, 0);
            labelHoy.Name = "labelHoy";
            labelHoy.Size = new Size(100, 23);
            labelHoy.TabIndex = 0;
            // 
            // pictureCitas
            // 
            pictureCitas.Location = new Point(0, 0);
            pictureCitas.Name = "pictureCitas";
            pictureCitas.Size = new Size(100, 50);
            pictureCitas.TabIndex = 0;
            pictureCitas.TabStop = false;
            // 
            // comboBoxFiltrar1
            // 
            comboBoxFiltrar1.Location = new Point(0, 0);
            comboBoxFiltrar1.Name = "comboBoxFiltrar1";
            comboBoxFiltrar1.Size = new Size(121, 23);
            comboBoxFiltrar1.TabIndex = 0;
            // 
            // BusCitas
            // 
            BusCitas.Location = new Point(0, 0);
            BusCitas.Name = "BusCitas";
            BusCitas.Size = new Size(100, 23);
            BusCitas.TabIndex = 0;
            // 
            // tablaCitas
            // 
            tablaCitas.Location = new Point(0, 0);
            tablaCitas.Name = "tablaCitas";
            tablaCitas.Size = new Size(200, 100);
            tablaCitas.TabIndex = 0;
            // 
            // picModificar3
            // 
            picModificar3.Image = (Image)resources.GetObject("picModificar3.Image");
            picModificar3.Location = new Point(904, 105);
            picModificar3.Margin = new Padding(4, 3, 4, 3);
            picModificar3.Name = "picModificar3";
            picModificar3.Size = new Size(67, 26);
            picModificar3.SizeMode = PictureBoxSizeMode.Zoom;
            picModificar3.TabIndex = 30;
            picModificar3.TabStop = false;
            // 
            // picModificar2
            // 
            picModificar2.Image = (Image)resources.GetObject("picModificar2.Image");
            picModificar2.Location = new Point(904, 69);
            picModificar2.Margin = new Padding(4, 3, 4, 3);
            picModificar2.Name = "picModificar2";
            picModificar2.Size = new Size(67, 29);
            picModificar2.SizeMode = PictureBoxSizeMode.Zoom;
            picModificar2.TabIndex = 29;
            picModificar2.TabStop = false;
            // 
            // picCancelar3
            // 
            picCancelar3.Image = (Image)resources.GetObject("picCancelar3.Image");
            picCancelar3.Location = new Point(981, 105);
            picCancelar3.Margin = new Padding(4, 3, 4, 3);
            picCancelar3.Name = "picCancelar3";
            picCancelar3.Size = new Size(66, 26);
            picCancelar3.SizeMode = PictureBoxSizeMode.Zoom;
            picCancelar3.TabIndex = 28;
            picCancelar3.TabStop = false;
            // 
            // picCancelar2
            // 
            picCancelar2.Image = (Image)resources.GetObject("picCancelar2.Image");
            picCancelar2.Location = new Point(981, 69);
            picCancelar2.Margin = new Padding(4, 3, 4, 3);
            picCancelar2.Name = "picCancelar2";
            picCancelar2.Size = new Size(66, 29);
            picCancelar2.SizeMode = PictureBoxSizeMode.Zoom;
            picCancelar2.TabIndex = 27;
            picCancelar2.TabStop = false;
            // 
            // labEstado
            // 
            labEstado.AutoSize = true;
            labEstado.Dock = DockStyle.Fill;
            labEstado.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labEstado.ForeColor = Color.SeaGreen;
            labEstado.Location = new Point(814, 102);
            labEstado.Margin = new Padding(4, 0, 4, 0);
            labEstado.Name = "labEstado";
            labEstado.Size = new Size(81, 32);
            labEstado.TabIndex = 25;
            labEstado.Text = "Confirmada";
            labEstado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labFecHo3
            // 
            labFecHo3.AutoSize = true;
            labFecHo3.Dock = DockStyle.Fill;
            labFecHo3.ForeColor = SystemColors.ControlText;
            labFecHo3.Location = new Point(660, 102);
            labFecHo3.Margin = new Padding(4, 0, 4, 0);
            labFecHo3.Name = "labFecHo3";
            labFecHo3.Size = new Size(145, 32);
            labFecHo3.TabIndex = 24;
            labFecHo3.Text = "vie. 7 nov 2025 13:00";
            labFecHo3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labServicio3
            // 
            labServicio3.AutoSize = true;
            labServicio3.Dock = DockStyle.Fill;
            labServicio3.ForeColor = SystemColors.ControlText;
            labServicio3.Location = new Point(552, 102);
            labServicio3.Margin = new Padding(4, 0, 4, 0);
            labServicio3.Name = "labServicio3";
            labServicio3.Size = new Size(99, 32);
            labServicio3.TabIndex = 23;
            labServicio3.Text = "Corte y Peinado";
            labServicio3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labGrupo3
            // 
            labGrupo3.AutoSize = true;
            labGrupo3.Dock = DockStyle.Fill;
            labGrupo3.ForeColor = SystemColors.ControlText;
            labGrupo3.Location = new Point(273, 102);
            labGrupo3.Margin = new Padding(4, 0, 4, 0);
            labGrupo3.Name = "labGrupo3";
            labGrupo3.Size = new Size(270, 32);
            labGrupo3.TabIndex = 22;
            labGrupo3.Text = "2º PELU";
            labGrupo3.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labCliente
            // 
            labCliente.AutoSize = true;
            labCliente.Dock = DockStyle.Fill;
            labCliente.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labCliente.ForeColor = SystemColors.ControlText;
            labCliente.Location = new Point(5, 102);
            labCliente.Margin = new Padding(4, 0, 4, 0);
            labCliente.Name = "labCliente";
            labCliente.Size = new Size(259, 32);
            labCliente.TabIndex = 21;
            labCliente.Text = "Ana Rodríguez";
            labCliente.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labEstado2
            // 
            labEstado2.AutoSize = true;
            labEstado2.Dock = DockStyle.Fill;
            labEstado2.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labEstado2.ForeColor = Color.Firebrick;
            labEstado2.Location = new Point(814, 66);
            labEstado2.Margin = new Padding(4, 0, 4, 0);
            labEstado2.Name = "labEstado2";
            labEstado2.Size = new Size(81, 35);
            labEstado2.TabIndex = 18;
            labEstado2.Text = "Cancelada";
            labEstado2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labFecHo2
            // 
            labFecHo2.AutoSize = true;
            labFecHo2.Dock = DockStyle.Fill;
            labFecHo2.ForeColor = SystemColors.ControlText;
            labFecHo2.Location = new Point(660, 66);
            labFecHo2.Margin = new Padding(4, 0, 4, 0);
            labFecHo2.Name = "labFecHo2";
            labFecHo2.Size = new Size(145, 35);
            labFecHo2.TabIndex = 17;
            labFecHo2.Text = "vie. 7 nov 2025 12:15";
            labFecHo2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labServicio2
            // 
            labServicio2.AutoSize = true;
            labServicio2.Dock = DockStyle.Fill;
            labServicio2.ForeColor = SystemColors.ControlText;
            labServicio2.Location = new Point(552, 66);
            labServicio2.Margin = new Padding(4, 0, 4, 0);
            labServicio2.Name = "labServicio2";
            labServicio2.Size = new Size(99, 35);
            labServicio2.TabIndex = 16;
            labServicio2.Text = "Color";
            labServicio2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labGrupo2
            // 
            labGrupo2.AutoSize = true;
            labGrupo2.Dock = DockStyle.Fill;
            labGrupo2.ForeColor = SystemColors.ControlText;
            labGrupo2.Location = new Point(273, 66);
            labGrupo2.Margin = new Padding(4, 0, 4, 0);
            labGrupo2.Name = "labGrupo2";
            labGrupo2.Size = new Size(270, 35);
            labGrupo2.TabIndex = 15;
            labGrupo2.Text = "1º PELU";
            labGrupo2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labCliente2
            // 
            labCliente2.AutoSize = true;
            labCliente2.Dock = DockStyle.Fill;
            labCliente2.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labCliente2.ForeColor = SystemColors.ControlText;
            labCliente2.Location = new Point(5, 66);
            labCliente2.Margin = new Padding(4, 0, 4, 0);
            labCliente2.Name = "labCliente2";
            labCliente2.Size = new Size(259, 35);
            labCliente2.TabIndex = 14;
            labCliente2.Text = "Carmen López";
            labCliente2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // celTiCliente
            // 
            celTiCliente.AutoSize = true;
            celTiCliente.BackColor = Color.Bisque;
            celTiCliente.Dock = DockStyle.Fill;
            celTiCliente.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            celTiCliente.ForeColor = SystemColors.ControlText;
            celTiCliente.Location = new Point(5, 1);
            celTiCliente.Margin = new Padding(4, 0, 4, 0);
            celTiCliente.Name = "celTiCliente";
            celTiCliente.Size = new Size(259, 25);
            celTiCliente.TabIndex = 0;
            celTiCliente.Text = "Cliente";
            celTiCliente.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labTiGrupo
            // 
            labTiGrupo.AutoSize = true;
            labTiGrupo.BackColor = Color.Bisque;
            labTiGrupo.Dock = DockStyle.Fill;
            labTiGrupo.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labTiGrupo.ForeColor = SystemColors.ControlText;
            labTiGrupo.Location = new Point(273, 1);
            labTiGrupo.Margin = new Padding(4, 0, 4, 0);
            labTiGrupo.Name = "labTiGrupo";
            labTiGrupo.Size = new Size(270, 25);
            labTiGrupo.TabIndex = 1;
            labTiGrupo.Text = "Grupo";
            labTiGrupo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labTiServicio
            // 
            labTiServicio.AutoSize = true;
            labTiServicio.BackColor = Color.Bisque;
            labTiServicio.Dock = DockStyle.Fill;
            labTiServicio.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labTiServicio.ForeColor = SystemColors.ControlText;
            labTiServicio.Location = new Point(552, 1);
            labTiServicio.Margin = new Padding(4, 0, 4, 0);
            labTiServicio.Name = "labTiServicio";
            labTiServicio.Size = new Size(99, 25);
            labTiServicio.TabIndex = 2;
            labTiServicio.Text = "Servicio";
            labTiServicio.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labTiFecHo
            // 
            labTiFecHo.AutoSize = true;
            labTiFecHo.BackColor = Color.Bisque;
            labTiFecHo.Dock = DockStyle.Fill;
            labTiFecHo.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labTiFecHo.ForeColor = SystemColors.ControlText;
            labTiFecHo.Location = new Point(660, 1);
            labTiFecHo.Margin = new Padding(4, 0, 4, 0);
            labTiFecHo.Name = "labTiFecHo";
            labTiFecHo.Size = new Size(145, 25);
            labTiFecHo.TabIndex = 3;
            labTiFecHo.Text = "Fecha y Hora";
            labTiFecHo.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labTiEstado
            // 
            labTiEstado.AutoSize = true;
            labTiEstado.BackColor = Color.Bisque;
            labTiEstado.Dock = DockStyle.Fill;
            labTiEstado.Font = new Font("Microsoft Sans Serif", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labTiEstado.ForeColor = SystemColors.ControlText;
            labTiEstado.Location = new Point(814, 1);
            labTiEstado.Margin = new Padding(4, 0, 4, 0);
            labTiEstado.Name = "labTiEstado";
            labTiEstado.Size = new Size(81, 25);
            labTiEstado.TabIndex = 4;
            labTiEstado.Text = "Estado";
            labTiEstado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labTiModificar
            // 
            labTiModificar.AutoSize = true;
            labTiModificar.BackColor = Color.Bisque;
            labTiModificar.Dock = DockStyle.Fill;
            labTiModificar.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labTiModificar.ForeColor = SystemColors.ControlText;
            labTiModificar.Location = new Point(904, 1);
            labTiModificar.Margin = new Padding(4, 0, 4, 0);
            labTiModificar.Name = "labTiModificar";
            labTiModificar.Size = new Size(68, 25);
            labTiModificar.TabIndex = 5;
            labTiModificar.Text = "Modificar";
            labTiModificar.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // TablaUsCancelar
            // 
            TablaUsCancelar.AutoSize = true;
            TablaUsCancelar.BackColor = Color.Bisque;
            TablaUsCancelar.Dock = DockStyle.Fill;
            TablaUsCancelar.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            TablaUsCancelar.ForeColor = SystemColors.ControlText;
            TablaUsCancelar.Location = new Point(981, 1);
            TablaUsCancelar.Margin = new Padding(4, 0, 4, 0);
            TablaUsCancelar.Name = "TablaUsCancelar";
            TablaUsCancelar.Size = new Size(80, 25);
            TablaUsCancelar.TabIndex = 6;
            TablaUsCancelar.Text = "Cancelar";
            TablaUsCancelar.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labCliente1
            // 
            labCliente1.AutoSize = true;
            labCliente1.Dock = DockStyle.Fill;
            labCliente1.Font = new Font("Microsoft Sans Serif", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labCliente1.ForeColor = SystemColors.ControlText;
            labCliente1.Location = new Point(5, 27);
            labCliente1.Margin = new Padding(4, 0, 4, 0);
            labCliente1.Name = "labCliente1";
            labCliente1.Size = new Size(259, 38);
            labCliente1.TabIndex = 7;
            labCliente1.Text = "Luis Fernández";
            labCliente1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labGrupo1
            // 
            labGrupo1.AutoSize = true;
            labGrupo1.Dock = DockStyle.Fill;
            labGrupo1.ForeColor = SystemColors.ControlText;
            labGrupo1.Location = new Point(273, 27);
            labGrupo1.Margin = new Padding(4, 0, 4, 0);
            labGrupo1.Name = "labGrupo1";
            labGrupo1.Size = new Size(270, 38);
            labGrupo1.TabIndex = 8;
            labGrupo1.Text = "1º PELU";
            labGrupo1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labServicio1
            // 
            labServicio1.AutoSize = true;
            labServicio1.Dock = DockStyle.Fill;
            labServicio1.ForeColor = SystemColors.ControlText;
            labServicio1.Location = new Point(552, 27);
            labServicio1.Margin = new Padding(4, 0, 4, 0);
            labServicio1.Name = "labServicio1";
            labServicio1.Size = new Size(99, 38);
            labServicio1.TabIndex = 9;
            labServicio1.Text = "Corte";
            labServicio1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labFecHo1
            // 
            labFecHo1.AutoSize = true;
            labFecHo1.Dock = DockStyle.Fill;
            labFecHo1.ForeColor = SystemColors.ControlText;
            labFecHo1.Location = new Point(660, 27);
            labFecHo1.Margin = new Padding(4, 0, 4, 0);
            labFecHo1.Name = "labFecHo1";
            labFecHo1.Size = new Size(145, 38);
            labFecHo1.TabIndex = 10;
            labFecHo1.Text = "vie. 7 nov 2025 11:00";
            labFecHo1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labEstado1
            // 
            labEstado1.AutoSize = true;
            labEstado1.Dock = DockStyle.Fill;
            labEstado1.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labEstado1.ForeColor = Color.SeaGreen;
            labEstado1.Location = new Point(814, 27);
            labEstado1.Margin = new Padding(4, 0, 4, 0);
            labEstado1.Name = "labEstado1";
            labEstado1.Size = new Size(81, 38);
            labEstado1.TabIndex = 11;
            labEstado1.Text = "Confirmada";
            labEstado1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // picCancelar1
            // 
            picCancelar1.Image = (Image)resources.GetObject("picCancelar1.Image");
            picCancelar1.Location = new Point(981, 30);
            picCancelar1.Margin = new Padding(4, 3, 4, 3);
            picCancelar1.Name = "picCancelar1";
            picCancelar1.Size = new Size(66, 30);
            picCancelar1.SizeMode = PictureBoxSizeMode.Zoom;
            picCancelar1.TabIndex = 12;
            picCancelar1.TabStop = false;
            // 
            // picModificar1
            // 
            picModificar1.Image = (Image)resources.GetObject("picModificar1.Image");
            picModificar1.Location = new Point(904, 30);
            picModificar1.Margin = new Padding(4, 3, 4, 3);
            picModificar1.Name = "picModificar1";
            picModificar1.Size = new Size(67, 30);
            picModificar1.SizeMode = PictureBoxSizeMode.Zoom;
            picModificar1.TabIndex = 13;
            picModificar1.TabStop = false;
            // 
            // Principal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1231, 704);
            Controls.Add(panelTitulo);
            Controls.Add(panelLado);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Margin = new Padding(4, 3, 4, 3);
            Name = "Principal";
            Text = "Gestión";
            WindowState = FormWindowState.Maximized;
          

            panelLado.ResumeLayout(false);
            panelCerrar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)picLogo).EndInit();
            panelTitulo.ResumeLayout(false);
            panelTitulo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBloqueados).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureCanceladas).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureProx).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureCitas).EndInit();
            ((System.ComponentModel.ISupportInitialize)picModificar3).EndInit();
            ((System.ComponentModel.ISupportInitialize)picModificar2).EndInit();
            ((System.ComponentModel.ISupportInitialize)picCancelar3).EndInit();
            ((System.ComponentModel.ISupportInitialize)picCancelar2).EndInit();
            ((System.ComponentModel.ISupportInitialize)picCancelar1).EndInit();
            ((System.ComponentModel.ISupportInitialize)picModificar1).EndInit();
            ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelLado;
        private System.Windows.Forms.Panel panelTitulo;
        private System.Windows.Forms.Label labTituto;
        private System.Windows.Forms.Label labSubTituto;
        private System.Windows.Forms.Panel panelVisualCitas;
        private System.Windows.Forms.TableLayoutPanel tablaCitas;
        private System.Windows.Forms.Label celTiCliente;
        private System.Windows.Forms.Label labTiGrupo;
        private System.Windows.Forms.Label labTiServicio;
        private System.Windows.Forms.Label labTiEstado;
        private System.Windows.Forms.Label labTiModificar;
        private System.Windows.Forms.Label labTiFecHo;
        private System.Windows.Forms.Label TablaUsCancelar;
        private System.Windows.Forms.Label labCliente1;
        private System.Windows.Forms.Label labGrupo1;
        private System.Windows.Forms.Label labServicio1;
        private System.Windows.Forms.Label labFecHo1;
        private System.Windows.Forms.Label labEstado1;
        private System.Windows.Forms.PictureBox picCancelar1;
        private System.Windows.Forms.PictureBox picModificar1;
        private System.Windows.Forms.Label labEstado;
        private System.Windows.Forms.Label labFecHo3;
        private System.Windows.Forms.Label labServicio3;
        private System.Windows.Forms.Label labGrupo3;
        private System.Windows.Forms.Label labCliente;
        private System.Windows.Forms.Label labEstado2;
        private System.Windows.Forms.Label labFecHo2;
        private System.Windows.Forms.Label labServicio2;
        private System.Windows.Forms.Label labGrupo2;
        private System.Windows.Forms.Label labCliente2;
        private System.Windows.Forms.ComboBox comboBoxFiltrar1;
        private System.Windows.Forms.TextBox BusCitas;
        private PictureBox picLogo;
        private Panel paDiasBloq;
        private Label labelNumBloqueados;
        private Label labelBloqueados;
        private PictureBox pictureBloqueados;
        private Panel paCitasCan;
        private Label labelNumCanceladas;
        private Label labelCanceladas;
        private PictureBox pictureCanceladas;
        private Panel PCitasProx;
        private Label labelNumProx;
        private Label labelProx;
        private PictureBox pictureProx;
        private Panel pCitasHoy;
        private Label labelNumCitas;
        private Label labelHoy;
        private PictureBox pictureCitas;
        private PictureBox picModificar3;
        private PictureBox picModificar2;
        private PictureBox picCancelar3;
        private PictureBox picCancelar2;
        private Button buttonCerrar;
        private Panel panelCerrar;
    }
}

